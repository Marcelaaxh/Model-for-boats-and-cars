#ifndef TRANSPORTE_H
#define TRANSPORTE_H

#include <string>
#include <iostream>
using namespace std;

class Transporte {

protected:
    string nombre;
    int litrosGasolina;

public:
    //Constructores
    Transporte();
    Transporte(string nombre, int litrosGasolina);
    virtual ~Transporte() {}

    string getNombre();
    int getLitrosGasolina();
    virtual void movilidad() = 0; //Clase abstracta

};

#endif