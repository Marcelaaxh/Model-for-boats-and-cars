#include "Barcos.h"

Barcos::Barcos() : Transporte() {
}

Barcos::Barcos(string nombre, int litrosGasolina) : Transporte(nombre, litrosGasolina) {
}

void Barcos::movilidad() {
    if (nombre == "Vela") {
        cout << "Este bote de vela alcanza una velocidad máxima de 15 nudos y puede ser usado en el mar." << endl;
    } else if (nombre == "Motor") {
        cout << "Este bote con motor alcanza una velocidad máxima de 25 nudos y puede ser usado en el mar." << endl;
    } else if (nombre == "Remos") {
        cout << "Este bote de remos alcanza una velocidad máxima de 5 nudos y puede ser usado en lagos." << endl;
    }
}