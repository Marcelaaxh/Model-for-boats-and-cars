#ifndef AUTOS_H
#define AUTOS_H

#include "Transporte.h"

class Autos : public Transporte {

public:
    Autos();
    Autos(string nombre, int litrosGasolina);
    void movilidad() override;
};

#endif
