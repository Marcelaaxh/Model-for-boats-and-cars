#include "Transporte.h"

Transporte::Transporte()
{
    nombre = "n/a";
    litrosGasolina = 50; //Valor 50 litros por default
}

Transporte::Transporte(string nombre, int litrosGasolina)
    : nombre(nombre), litrosGasolina(litrosGasolina) {}

string Transporte::getNombre() {
    return nombre;
}

int Transporte::getLitrosGasolina() {
    return litrosGasolina;
}
