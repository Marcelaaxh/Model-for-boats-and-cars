#ifndef BARCOS_H
#define BARCOS_H

#include "Transporte.h"

class Barcos : public Transporte {

public:
    Barcos();
    Barcos(string nombre, int litrosGasolina);
    void movilidad() override;

};



#endif
