#include "Autos.h"

Autos::Autos() : Transporte() {
  
}

Autos::Autos(string nombre, int litrosGasolina) : Transporte(nombre, litrosGasolina) {}

void Autos::movilidad() {
    if (nombre == "Auto de Carreras") {
        cout << "Este auto de carreras alcanza una velocidad máxima de 300 km/h y puede ser conducido en circuitos especializados." << endl;
    } else if (nombre == "Go-Kart") {
        cout << "Este Go-Kart alcanza una velocidad máxima de 80 km/h y puede ser conducido en pistas de go-kart." << endl;
    } else {
        cout << "Este auto es de uso general y alcanza una velocidad máxima de 120 km/h." << endl;
    }
}