#include <iostream>

class Sobrecarga {

private:
    int totalLitrosGasolina;

public:
    Sobrecarga() : totalLitrosGasolina(0) {}

    void operator+=(int litros) {
        totalLitrosGasolina += litros;
    }

    int getTotalLitrosGasolina() const {
        return totalLitrosGasolina;
    }
};