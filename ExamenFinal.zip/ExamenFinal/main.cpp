#include <iostream>
#include "Autos.h"
#include "Barcos.h"
#include "Sobrecarga.h"

using namespace std;

int main() {
    // Crear objetos Autos
    Autos autoCarreras("Auto de Carreras", 50);
    Autos goKart("Go-Kart", 30);
    Autos autoGeneral("Auto de Uso General", 40);

    // Crear objetos Barcos
    Barcos boteVela("Vela", 20);
    Barcos boteMotor("Motor", 25);
    Barcos boteRemos("Remos", 15);

    // Arreglo de punteros a objetos Transporte
    Transporte* transportes[6];
    transportes[0] = &autoCarreras;
    transportes[1] = &goKart;
    transportes[2] = &autoGeneral;
    transportes[3] = &boteVela;
    transportes[4] = &boteMotor;
    transportes[5] = &boteRemos;

    // Mostrar información de los transportes y su movilidad
    for (int i = 0; i < 6; i++) {
        cout << "Transporte #" << (i + 1) << endl;
        cout << "Nombre: " << transportes[i]->getNombre() << endl;
        cout << "Litros de gasolina: " << transportes[i]->getLitrosGasolina() << endl;
        transportes[i]->movilidad();
        cout << endl;
    }

    // Sumar la cantidad total de litros de gasolina usando la sobrecarga 
  
  Sobrecarga sobrecarga;
    for (int i = 0; i < 6; i++) {
        sobrecarga += transportes[i]->getLitrosGasolina();
    }

    cout << "Total de litros de gasolina: " << sobrecarga.getTotalLitrosGasolina() << endl;

    return 0;
}
